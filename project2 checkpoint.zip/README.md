Project 2 for IGME 430 @ RIT
By Vincent Li
